import 'package:test/test.dart';
import 'package:new_project/src/data/rental_database.dart';
import 'package:new_project/src/models/client.dart';
import 'package:new_project/src/models/car.dart';
import 'package:new_project/src/models/car_brand.dart';

void main() {
  late RentalDatabase db;

  // Выполняется ПЕРЕД каждым тестом: создаёт чистую БД в памяти
  setUp(() {
    db = RentalDatabase(':memory:');
  });

  // Выполняется ПОСЛЕ каждого теста: закрывает соединение
  tearDown(() {
    db.close();
  });

  group('Client CRUD', () {
    test('Добавление и чтение клиента', () {
      final client = Client(
        id: null,
        fullName: 'Исаханян Давид',
        phone: '+7777777777',
        passport: '4522 123456',
        driverLicense: '9900123456',
      );

      db.insertClient(client);
      final clients = db.getAllClients();

      expect(clients.length, 1);
      expect(clients.first.fullName, 'Исаханян Давид');
      expect(clients.first.phone, '+7777777777');
    });

    test('Удаление клиента', () {
      final client = Client(
        id: null,
        fullName: 'Тест',
        phone: '123',
        passport: '123',
        driverLicense: '123',
      );
      db.insertClient(client);
      expect(db.getAllClients().length, 1);

      db.deleteClient(1);
      expect(db.getAllClients().length, 0);
    });
  });

  group('Car CRUD', () {
    test('Добавление автомобиля (с учётом FOREIGN KEY)', () {
      db.insertCarBrand(CarBrand(id: null, name: 'Toyota'));

      final car = Car(
        id: null,
        brandId: 1, 
        model: 'Camry',
        year: 2023,
        vin: '1HGCM82633A123456',
        color: 'Черный',
        licensePlate: 'A777AA77',
        milleage: 15000.0,
        rentalPrice: 3500.0,
        isAvalaible: true,
      );

      db.insertCar(car);
      final cars = db.getAllCars();

      expect(cars.length, 1);
      expect(cars.first.model, 'Camry');
      expect(cars.first.rentalPrice, 3500.0);
    });
  });

  group('Validation Logic (требование преподавателя)', () {
    test('Обязательное текстовое поле (не пустое после trim)', () {
      bool isRequiredValid(String? input) => 
          input != null && input.trim().isNotEmpty;

      expect(isRequiredValid(''), isFalse);       // Ошибка (пустая строка)
      expect(isRequiredValid('   '), isFalse);    // Ошибка (пробелы)
      expect(isRequiredValid('Валидный текст'), isTrue); // ОК
    });

    test('Числовое поле > 0 (цена/пробег)', () {
      bool isPositiveValid(String? input) {
        final n = double.tryParse(input ?? '');
        return n != null && n > 0;
      }

      expect(isPositiveValid('-5'), isFalse);     // Ошибка (Отрицательное число)
      expect(isPositiveValid('0'), isFalse);      // Ошибка (Ноль)
      expect(isPositiveValid('abc'), isFalse);    // Ошибка (Буквы)
      expect(isPositiveValid('10.5'), isTrue);    // Нет ошибки!
    });
  });
}