class TextValidator {
  // Строка не пустая после trim()
  static bool isNotEmpty(String value) {
    return value.trim().isNotEmpty;
  }

  // Телефон содержит минимум 10 цифр
  static bool isValidPhone(String value) {
    final digits = value.replaceAll(RegExp(r'\D'), '');
    return digits.length >= 10;
  }

  
  /// Паспорт РФ: 10 цифр
  static bool isValidPassport(String value) {
    final digits = value.replaceAll(RegExp(r'\D'), '');
    return digits.length == 10;
  }

  /// Водительское удостоверение: 2 буквы + 6 цифр или 10 цифр
  static bool isValidDriverLicense(String value) {
    final cleaned = value.replaceAll(' ', '').toUpperCase();
    final pattern = RegExp(r'^[А-ЯЁ]{2}\d{6}$');
    final digitsOnly = RegExp(r'^\d{10}$');
    return pattern.hasMatch(cleaned) || digitsOnly.hasMatch(value.replaceAll(RegExp(r'\D'), ''));
  }

  /// VIN-код: 17 символов
  static bool isValidVin(String value) {
    if (value.length != 17) return false;
    final pattern = RegExp(r'^[A-HJ-NPR-Z0-9]{17}$');
    return pattern.hasMatch(value.toUpperCase());
  }

  /// Госномер РФ
  static bool isValidLicensePlate(String value) {
    final cleaned = value.replaceAll(' ', '').toUpperCase();
    final pattern = RegExp(r'^[А-ЯЁ]\d{3}[А-ЯЁ]{2}\d{2,3}$');
    return pattern.hasMatch(cleaned);
  } 

  /// Тип топлива
  static bool isValidFuelType(String value) {
    final valid = ['petrol', 'diesel', 'electric', 'hybrid', 'gas'];
    return valid.contains(value.toLowerCase());
  }

  /// Тип коробки
  static bool isValidTransmission(String value) {
    final valid = ['manual', 'automatic', 'cvt', 'robot'];
    return valid.contains(value.toLowerCase());
  }
}