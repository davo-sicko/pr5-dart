class NumberValidator {
  // Число строго больше 0
  static bool isPositive(num? value) {
    return value != null && value > 0;
  }

  // Цена: положительное число
  static bool isValidPrice(num? value) {
    return isPositive(value);
  }

  // Год: от 1900 до следующего года
  static bool isValidYear(int? year) {
    return year != null && year >= 1900 && year <= DateTime.now().year + 1;
  }
  
  /// Пробег: неотрицательное число
  static bool isValidMileage(num? value) {
    return value != null && value >= 0;
  }

  /// Цена аренды: строго положительная
  static bool isValidRentalPrice(num? value) {
    return isPositive(value);
  }

  /// Залог: неотрицательное число
  static bool isValidDeposit(num? value) {
    return value != null && value >= 0;
  }

  /// Итоговая стоимость: неотрицательная
  static bool isValidFinalCost(num? value) {
    return value != null && value >= 0;
  }

  /// Мощность двигателя: > 0
  static bool isValidPower(num? value) {
    return isPositive(value);
  }

  /// Количество мест: от 1 до 20
  static bool isValidSeats(int? value) {
    return value != null && value >= 1 && value <= 20;
  }

  /// Дата начала раньше даты окончания
  static bool isValidRentalPeriod(DateTime start, DateTime end) {
    return start.isBefore(end);
  }
}