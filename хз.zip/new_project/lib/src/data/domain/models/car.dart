// Таблица машины

import 'package:new_project/src/data/domain/models/identity.dart';

class Car implements Identity{
  @override
  final int? id;
  final int brandId;
  final String model;
  final int year;
  final String vin; // документ о т.с, состоящий из 17 СИМВОЛОВ (буквы + символы)
  final String color;
  final String licensePlate; 
  final double milleage; // Пробег
  final double rentalPrice; // Арендная стоимость за день
  final bool isAvalaible; // 1 - доступна; 2 - занята 

  const Car({
    required this.id,
    required this.brandId,
    required this.model,
    required this.year,
    required this.vin,
    required this.color,
    required this.licensePlate,
    required this.milleage,
    required this.rentalPrice,
    required this.isAvalaible,
  });

  Map<String, dynamic> toMap(){
    return{
      'id': id,
      'brand_id': brandId,
      'model': model,
      'year': year,
      'vin': vin,
      'color': color,
      'license_plate': licensePlate,
      'milleage': milleage,
      'rental_price': rentalPrice,
      'is_avalaible': isAvalaible,
    };
  }
  factory Car.fromMap(Map<String, dynamic> map){
  return Car(
    id:map['id'] as int?,
    brandId:map['brand_id'] as int,
    model:map['model'] as String,
    year:map['year'] as int,
    vin:map['vin'] as String,
    color:map['color'] as String,
    licensePlate:map['license_plate'] as String,
    milleage:(map['milleage'] as num).toDouble(),
    rentalPrice:(map['rental_price'] as num).toDouble(),
    isAvalaible:map['is_avalaible'] == 1,
  );
}
}