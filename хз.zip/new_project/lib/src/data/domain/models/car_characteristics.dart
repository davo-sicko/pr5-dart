// Таблица: Характеристики машин
import 'package:new_project/src/models/identity.dart';

class CarCharacteristics implements Identity{
  @override
  final int? id;
  final int carId;
  final String engineVolume;
  final double power;
  final String transmission; // Механика, автомат
  final String fuelType;  // 95, 92, 100 или даже электрика
  final int seats;

  const CarCharacteristics({
    required this.id,
    required this.carId,
    required this.engineVolume,
    required this.power,
    required this.transmission,
    required this.fuelType,
    required this.seats,
  });

  Map<String, dynamic> toMap(){
    return{
      'id': id,
      'car_id': carId,
      'engine_volume': engineVolume,
      'power': power,
      'transmission': transmission,
      'fuel_type': fuelType,
      'seats': seats,
    };
  }
  factory CarCharacteristics.fromMap(Map<String, dynamic> map){
  return CarCharacteristics(
    id:map['id'] as int?,
    carId:map['car_id'] as int,
    engineVolume:map['engine_volume'] as String,
    power:(map['power'] as num).toDouble(),
    transmission:map['transmission'] as String,
    fuelType:map['fuel_type'] as String,
    seats:map['seats'] as int,
  );
}
}