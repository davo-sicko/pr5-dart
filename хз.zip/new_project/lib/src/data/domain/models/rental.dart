// Таблица клиенты

import 'package:new_project/src/models/identity.dart';

class Rental implements Identity{
  @override
  final int? id;
  final String clientId;
  final int carId;
  final String startDate;
  final String endDate; 
  final String finalCost;

  const Rental({
    required this.id,
    required this.clientId,
    required this.carId,
    required this.startDate,
    required this.endDate,
    required this.finalCost,
  });

  Map<String, dynamic> toMap(){
    return{
      'id': id,
      'client_id': clientId,
      'car_id': carId,
      'start_date': startDate,
      'end_date': endDate,
      'final_cost': finalCost,
    };
  }
  factory Rental.fromMap(Map<String, dynamic> map){
  return Rental(
    id:map['id'] as int?,
    clientId:map['client_id'] as String,
    carId:map['car_id'] as int,
    startDate:map['start_date'] as String,
    endDate:map['end_date'] as String,
    finalCost:map['final_cost'] as String,
  );
}
}