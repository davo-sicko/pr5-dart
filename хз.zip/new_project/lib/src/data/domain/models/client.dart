// Таблица клиенты

import 'package:new_project/src/data/domain/models/identity.dart';

class Client implements Identity{
  @override
  final int? id;
  final String fullName;
  final String phone;
  final String passport;
  final String driverLicense;

  const Client({
    required this.id,
    required this.fullName,
    required this.phone,
    required this.passport,
    required this.driverLicense,
  });

  Map<String, dynamic> toMap(){
    return{
      'id': id,
      'full_name': fullName,
      'phone': phone,
      'passport': passport,
      'driver_license': driverLicense,
    };
  }
  factory Client.fromMap(Map<String, dynamic> map){
  return Client(
    id:map['id'] as int?,
    fullName:map['full_name'] as String,
    phone:map['phone'] as String,
    passport:map['passport'] as String,
    driverLicense:map['driver_license'] as String,
    
  );
}
}