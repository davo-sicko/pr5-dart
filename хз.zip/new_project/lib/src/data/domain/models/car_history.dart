// Таблица: история машины (тип события который произошел)
import 'package:new_project/src/models/identity.dart';


class CarHistory implements Identity{
  @override
  final int? id;
  final int carId;
  final String eventDate; 
  final String eventType; // Замена чего либо, авария, ремонт
  final String description; 
  final double cost;  

  const CarHistory({
    required this.id,
    required this.carId,
    required this.eventDate,
    required this.eventType,
    required this.description,
    required this.cost,
  });

  Map<String, dynamic> toMap(){
    return{
      'id': id,
      'car_id': carId,
      'event_date': eventDate,
      'event_type': eventType,
      'description': description,
      'cost': cost,
    };
  }
  factory CarHistory.fromMap(Map<String, dynamic> map){
  return CarHistory(
    id:map['id'] as int?,
    carId:map['car_id'] as int,
    eventType:map['event_type'] as String,
    eventDate:map['event_date'] as String,
    description:map['description'] as String,
    cost:(map['cost'] as num).toDouble(),
  );
}
}