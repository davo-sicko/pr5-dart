// Таблица: марка машин
import 'package:new_project/src/data/domain/models/identity.dart';

class CarBrand implements Identity {
  @override
  final int? id;
  final String name;

  const CarBrand({
    required this.id,
    required this.name,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
    };
  }

  factory CarBrand.fromMap(Map<String, dynamic> map) {
    return CarBrand(
      id: map['id'] as int?,
      name: map['name'] as String,
    );
  }
}