import 'dart:io';
import 'package:sqlite3/sqlite3.dart';
import 'package:path/path.dart' as p;

class AppDatabase {
  final Database sqlite;

  AppDatabase(String filePath) : sqlite = sqlite3.open(filePath) {
    _createTables();
  }

  factory AppDatabase.inApp() {
    final path = p.join(Directory.current.path, 'shawarma.db');
    return AppDatabase(path);
  }

  void _createTables() {
    sqlite.execute('PRAGMA foreign_keys = ON;');

    sqlite.execute('''
      CREATE TABLE IF NOT EXISTS customers (
        id    TEXT PRIMARY KEY,
        name  TEXT NOT NULL,
        phone TEXT NOT NULL
      );
    ''');

    sqlite.execute('''
      CREATE TABLE IF NOT EXISTS menu_items (
        id          TEXT PRIMARY KEY,
        title       TEXT NOT NULL,
        description TEXT NOT NULL,
        price       REAL NOT NULL,
        weightGrams INTEGER NOT NULL
      );
    ''');

    sqlite.execute('''
      CREATE TABLE IF NOT EXISTS orders (
        id         TEXT PRIMARY KEY,
        customerId TEXT NOT NULL,
        menuItemId TEXT NOT NULL,
        quantity   INTEGER NOT NULL,
        orderTime  TEXT NOT NULL,
        FOREIGN KEY (customerId) REFERENCES customers(id) ON DELETE CASCADE,
        FOREIGN KEY (menuItemId) REFERENCES menu_items(id) ON DELETE CASCADE
      );
    ''');

    sqlite.execute('''
      CREATE TABLE IF NOT EXISTS ingredients (
        id          TEXT PRIMARY KEY,
        name        TEXT NOT NULL,
        unit        TEXT NOT NULL,
        stock       REAL NOT NULL,
        costPerUnit REAL NOT NULL
      );
    ''');
  }

  void dispose() {
    sqlite.dispose();
  }
}
