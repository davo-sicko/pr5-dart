import 'package:sqlite3/sqlite3.dart';
import '../domain/models/car.dart';

class CarRepository {
  final Database _db;

  CarRepository(this._db);

  void insert(Car c) {
    _db.execute(
      'INSERT OR REPLACE INTO cars (id, brand_id, model, year, vin, color, license_plate, milleage, rental_price, is_avalaible) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [
        c.id,
        c.brandId,
        c.model,
        c.year,
        c.vin,
        c.color,
        c.licensePlate,
        c.milleage,
        c.rentalPrice,
        c.isAvalaible ? 1 : 0,
      ],
    );
  }

  List<Car> getAll() {
    final rows = _db.select('SELECT * FROM cars');
    return rows.map((row) => Car.fromMap(row)).toList();
  }

  Car? getById(int id) {
    final rows = _db.select('SELECT * FROM cars WHERE id = ?', [id]);
    if (rows.isEmpty) return null;
    return Car.fromMap(rows.first);
  }

  void update(Car c) {
    _db.execute(
      'UPDATE cars SET brand_id = ?, model = ?, year = ?, vin = ?, color = ?, license_plate = ?, milleage = ?, rental_price = ?, is_avalaible = ? WHERE id = ?',
      [
        c.brandId,
        c.model,
        c.year,
        c.vin,
        c.color,
        c.licensePlate,
        c.milleage,
        c.rentalPrice,
        c.isAvalaible ? 1 : 0,
        c.id,
      ],
    );
  }

  void delete(int id) {
    _db.execute('DELETE FROM cars WHERE id = ?', [id]);
  }
}