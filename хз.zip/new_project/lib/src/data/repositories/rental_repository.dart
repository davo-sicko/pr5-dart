import 'package:sqlite3/sqlite3.dart';
import '../domain/models/rental.dart';

class RentalRepository {
  final Database _db;

  RentalRepository(this._db);

  void insert(Rental r) {
    _db.execute(
      'INSERT OR REPLACE INTO rentals (id, client_id, car_id, start_date, end_date, final_cost) VALUES (?, ?, ?, ?, ?, ?)',
      [r.id, r.clientId, r.carId, r.startDate, r.endDate, r.finalCost],
    );
  }

  List<Rental> getAll() {
    final rows = _db.select('SELECT * FROM rentals');
    return rows.map((row) => Rental.fromMap(row)).toList();
  }

  Rental? getById(int id) {
    final rows = _db.select('SELECT * FROM rentals WHERE id = ?', [id]);
    if (rows.isEmpty) return null;
    return Rental.fromMap(rows.first);
  }

  void update(Rental r) {
    _db.execute(
      'UPDATE rentals SET client_id = ?, car_id = ?, start_date = ?, end_date = ?, final_cost = ? WHERE id = ?',
      [r.clientId, r.carId, r.startDate, r.endDate, r.finalCost, r.id],
    );
  }

  void delete(int id) {
    _db.execute('DELETE FROM rentals WHERE id = ?', [id]);
  }
}