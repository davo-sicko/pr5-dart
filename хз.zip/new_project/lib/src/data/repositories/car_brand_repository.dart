import 'package:sqlite3/sqlite3.dart';
import '../domain/models/car_brand.dart';

class CarBrandRepository {
  final Database _db;

  CarBrandRepository(this._db);

  void insert(CarBrand b) {
    _db.execute(
      'INSERT OR REPLACE INTO car_brands (id, name) VALUES (?, ?)',
      [b.id, b.name],
    );
  }

  List<CarBrand> getAll() {
    final rows = _db.select('SELECT * FROM car_brands');
    return rows.map((row) => CarBrand.fromMap(row)).toList();
  }

  CarBrand? getById(int id) {
    final rows = _db.select('SELECT * FROM car_brands WHERE id = ?', [id]);
    if (rows.isEmpty) return null;
    return CarBrand.fromMap(rows.first);
  }

  void update(CarBrand b) {
    _db.execute(
      'UPDATE car_brands SET name = ? WHERE id = ?',
      [b.name, b.id],
    );
  }

  void delete(int id) {
    _db.execute('DELETE FROM car_brands WHERE id = ?', [id]);
  }
}