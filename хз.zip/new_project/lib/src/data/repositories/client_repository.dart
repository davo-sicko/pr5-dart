import 'package:sqlite3/sqlite3.dart';
import '../domain/client.dart';

class ClientRepository {
  final Database _db;

  ClientRepository(this._db);

  void insert(Client c) {
    _db.execute(
      'INSERT OR REPLACE INTO clients (id, full_name, phone, passport, driver_license) VALUES (?, ?, ?, ?, ?)',
      [c.id, c.fullName, c.phone, c.passport, c.driverLicense],
    );
  }

  List<Client> getAll() {
    final rows = _db.select('SELECT * FROM clients');
    return rows.map((row) => Client.fromMap(row)).toList();
  }

  Client? getById(int id) {
    final rows = _db.select('SELECT * FROM clients WHERE id = ?', [id]);
    if (rows.isEmpty) return null;
    return Client.fromMap(rows.first);
  }

  void update(Client c) {
    _db.execute(
      'UPDATE clients SET full_name = ?, phone = ?, passport = ?, driver_license = ? WHERE id = ?',
      [c.fullName, c.phone, c.passport, c.driverLicense, c.id],
    );
  }

  void delete(int id) {
    _db.execute('DELETE FROM clients WHERE id = ?', [id]);
  }
}