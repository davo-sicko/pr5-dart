import 'dart:io';
import 'package:new_project/src/data/rental_database.dart';
import 'package:new_project/src/data/domain/models/client.dart';
import 'package:new_project/src/data/domain/models/car.dart';
import 'input_helper.dart'; 

class Menu {
  final RentalDatabase db;

  Menu(this.db);

  void run() {
    while (true) {
      print('\nАренда автомобилей (Яндекс 2.0)');
      print('1. Клиенты');
      print('2. Автомобили');
      print('3. Просмотр доступных аренд');
      print('0. Выход из системы');

      print("Выберите пункт: ");
      int choice = int.parse(stdin.readLineSync()!);


      switch (choice) {
        case 1:
          _clientMenu();
          break;
        case 2:
          _carMenu();
          break;
        case 3:
          _rentalMenu();
          break;
        case 0:
          print(' До свидания!');
          return; 
        default:
          print('Неверный выбор, попробуйте снова.');
      }
    }
  }

  void _clientMenu() {
    while (true) {
      print('\nКлиенты');
      print('1. Показать всех клиентов');
      print('2. Добавить нового клиентов');
      print('0. Назад в главное меню');

      
      print("Выбор: ");
      String? choice1 = stdin.readLineSync();
      int? choice = int.tryParse(choice1 ?? '');

      if (choice == null) {
      print("Введите число еще раз...");
      continue;
    }


      if (choice == 1) {
        final clients = db.getAllClients();
        if (clients.isEmpty) {
          print(' Список пуст.');
        } else {
          for (var c in clients) {
            print('${c.id}: ${c.fullName} // ${c.phone}');
          }
        }
      } else if (choice == 2) {
        print('Введите данные клиента:');
        print("ФИО: ");
        final name = stdin.readLineSync() ?? '';
        print("Ваш телефон: ");
        final phone = stdin.readLineSync() ?? '';
        print("Ваш паспорт: ");
        final passport = stdin.readLineSync() ?? '';
        print("Водительские права: ");
        final license = stdin.readLineSync() ?? '';

        final newClient = Client(
          id: null, 
          fullName: name,
          phone: phone,
          passport: passport,
          driverLicense: license,
        );

        db.insertClient(newClient);
        print('Клиент успешно добавлен!');
      } else if (choice == 0) {
        break;
      }
    }
  }

  void _carMenu() {
    while (true) {
      print('\nАвтомобили');
      print('1. Показать все машины');
      print('2. Добавить машину');
      print('0. Назад');

      print("Выбор: ");
      String? choice1 = stdin.readLineSync();
      int? choice = int.tryParse(choice1 ?? '');

      if (choice == 1) {
        final cars = db.getAllCars();
        if (cars.isEmpty) {
          print('К сожалению, машин нет');
        } else {
          for (var car in cars) {
            final status = car.isAvalaible ? 'Свободна' : 'Занята';
            print('${car.id}: ${car.model} (${car.year}) — ${car.rentalPrice}₽ // $status');
          }
        }
      } else if (choice == 2) {
        print('Введите данные авто:');
        final brandId = readInt('ID Марки'); 
        final model = readString('Модель (например: мерс)');
        final year = readInt('Год выпуска');
        final vin = readString('VIN (17 символов)');
        final color = readString('Цвет');
        final plate = readString('Автомобильный номер');
        final mileage = readDouble('Пробег');
        final price = readDouble('Цена аренды за день');
        final isAvailable = readString('Доступна? (да/нет)');

        final newCar = Car(
          id: null,
          brandId: brandId,
          model: model,
          year: year,
          vin: vin,
          color: color,
          licensePlate: plate,
          milleage: mileage,
          rentalPrice: price,
          isAvalaible: isAvailable.toLowerCase() == 'да',
        );

        db.insertCar(newCar);
        print('Автомобиль добавлен в гараж!');
      } else if (choice == 0) {
        break;
      }
    }
  }

  void _rentalMenu() {
    final rentals = db.getAllRentals();
    print('\nСписок аренд');
    if (rentals.isEmpty) {
      print('Нет активных аренд.');
    } else {
      for (var r in rentals) {
        print('${r.id}: Клиент ID ${r.clientId} : Авто ID ${r.carId} // С ${r.startDate} по ${r.endDate}');
      }
    }
    print('Нажмите Enter для возврата...');
    stdin.readLineSync();
  }
}