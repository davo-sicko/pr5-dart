import 'dart:io';

String readString(String prompt) {
  stdout.write('$prompt: ');
  return stdin.readLineSync()?.trim() ?? '';
}

int readInt(String prompt) {
  while (true) {
    stdout.write('$prompt: ');
    final input = stdin.readLineSync()?.trim();
    final val = int.tryParse(input ?? '');
    if (val != null) return val;
    print('Ошибка: Введите целое число!');
  }
}

double readDouble(String prompt) {
  while (true) {
    stdout.write('$prompt: ');
    final input = stdin.readLineSync()?.trim();
    final val = double.tryParse(input ?? '');
    if (val != null) return val;
    print(' Ошибка: Введите число (можно с точкой)!');
  }
}